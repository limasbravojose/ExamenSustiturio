package pe.idat.appa17144008.data.network.response

data class ItemMenu(
    val titulo: String
)
