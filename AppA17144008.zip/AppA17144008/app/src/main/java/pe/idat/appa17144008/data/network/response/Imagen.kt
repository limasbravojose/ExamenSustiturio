package pe.idat.appa17144008.data.network.response

data class Imagen(
    val albumId: Int,
    val id: Int,
    val title: String,
    val thumbnailUrl: String
)
